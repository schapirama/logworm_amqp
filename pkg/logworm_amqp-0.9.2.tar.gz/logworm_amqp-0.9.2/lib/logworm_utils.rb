require 'logworm_amqp'

require File.dirname(__FILE__) + '/cmd/tail'
require File.dirname(__FILE__) + '/cmd/compute'
